const { getConnection, sql } = require('../config/database');

// Create Help Creation Entry
const createHelpCreation = async (req, res) => {
  try {
    const { menuId, menuName, description } = req.body;

    const pool = await getConnection();

    await pool.request()
      .input('menu_id', sql.NVarChar, menuId)
      .input('menu_name', sql.NVarChar, menuName)
      .input('description', sql.NVarChar, description)
      .query(`
        INSERT INTO HelpCreation (menu_id, menu_name, description)
        VALUES (@menu_id, @menu_name, @description);
      `);

    res.status(201).json({
      success: true,
      message: 'Added successfully',
      data: null
    });

  } catch (error) {
    console.error('Error in createHelpCreation:', error);
    res.status(500).json({
      success: false,
      message: 'Server error',
      data: error.message
    });
  }
};

// Update Help Creation Entry
const updateHelpCreation = async (req, res) => {
  try {
    const { menuId, menuName, description } = req.body;

    const pool = await getConnection();

    await pool.request()
      .input('menu_id', sql.NVarChar, menuId)
      .input('menu_name', sql.NVarChar, menuName)
      .input('description', sql.NVarChar, description)
      .query(`
        UPDATE HelpCreation
        SET menu_name = @menu_name,
            description = @description
        WHERE menu_id = @menu_id;
      `);

    res.json({
      success: true,
      message: 'Updated successfully',
      data: null
    });

  } catch (error) {
    console.error('Error in updateHelpCreation:', error);
    res.status(500).json({
      success: false,
      message: 'Server error',
      data: error.message
    });
  }
};

// Get All Help Creation Entries
const getHelpCreation = async (req, res) => {
  try {
    const { menuId } = req.query; 
    console.log('menuId:',menuId)

    const pool = await getConnection();

    let query = 'SELECT * FROM HelpCreation';
    const request = pool.request();

    if (menuId) {
      query += ' WHERE menu_id = @menu_id';
      request.input('menu_id', sql.NVarChar, menuId);
    }

    const result = await request.query(query);

    const helpCreation = result.recordset.map(item => ({
      menuId: item.menu_id,
      menuName: item.menu_name,
      description: item.description
    }));

    res.json({
      success: true,
      message: menuId ? 'Fetched help creation by menuId' : 'Fetched all help creation data',
      data: helpCreation
    });

  } catch (error) {
    console.error('Error in getHelpCreation:', error);
    res.status(500).json({
      success: false,
      message: 'Server error',
      data: error.message
    });
  }
};

// Delete Help Creation Entry
const deleteHelpCreation = async (req, res) => {
  try {
    const { id } = req.params;

    if (!id || isNaN(id)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid ID',
        data: null
      });
    }

    const pool = await getConnection();

    const result = await pool.request()
      .input('menu_id', sql.Int, id)
      .query(`
        DELETE FROM HelpCreation
        WHERE menu_id = @menu_id;
      `);

    if (result.rowsAffected[0] > 0) {
      res.json({
        success: true,
        message: 'Deleted successfully',
        data: null
      });
    } else {
      res.status(404).json({
        success: false,
        message: 'Help creation entry not found',
        data: null
      });
    }

  } catch (error) {
    console.error('Error in deleteHelpCreation:', error);
    res.status(500).json({
      success: false,
      message: 'Server error',
      data: error.message
    });
  }
};

module.exports = {
  getHelpCreation,
  createHelpCreation,
  updateHelpCreation,
  deleteHelpCreation
};
